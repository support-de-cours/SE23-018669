# APP MVC

## Initialisation du projet

- `composer init`
- Modif du namespace (`autoload > psr-4`) du fichier `composer.json`
- `composer dump-autoload`
- `git init`
- Ajout de `.gitignore`
- `git add *` ou `git add -A`
- `git add .gitignore`
- `git commit -m "Initial commit"`

## Demarrage du serveur

1. ouvrir le terminal sur le repertoire du projet `APP-MVC`
2. `php -S localhost:8080 -t public/`


## Creation de la table `book`

```sql
CREATE TABLE book(  
    id int NOT NULL PRIMARY KEY AUTO_INCREMENT COMMENT 'Primary Key',
    create_time DATETIME COMMENT 'Create Time',
    title VARCHAR(80),
    description TEXT,
    price DECIMAL(5,2)
) COMMENT '';
```
