<?php 

// Index.php est le fichier de démarage de l'application
// Il est le seul fichier PHP accessible par les utilisateurs

// On déclenche le bootstrap de l'application
include_once "../app/bootstrap.php";