<?php 

return [

    // Homepage
    [
        "homepage",                                     // Nom de la route
        "/",                                            // URL Path
        "App\Controller\HomepageController",     // Methode décclenché
        ['HEAD', 'GET']                                 // Methodes de requete autorisé
    ],

    // Book
    ["book:index",      "/livres",               "App\Controller\BookController::index",     ['HEAD', 'GET']],
    ["book:create",     "/livre",                "App\Controller\BookController::create",    ['HEAD', 'GET', 'POST']],
    ["book:read",       "/livre/{id}",           "App\Controller\BookController::read",      ['HEAD', 'GET']],
    ["book:update",     "/livre/{id}/edit",      "App\Controller\BookController::update",    ['HEAD', 'GET', 'POST']],
    ["book:delete",     "/livre/{id}/delete",    "App\Controller\BookController::delete",    ['HEAD', 'GET', 'DELETE']],

    // User
    ["user:index",      "/users",               "App\Controller\UserController::index",     ['HEAD', 'GET']],
    // ["user:create",     "/user",                "App\Controller\UserController::create",    ['HEAD', 'GET', 'POST']],
    ["user:read",       "/user/{id}",           "App\Controller\UserController::read",      ['HEAD', 'GET']],
    // ["user:update",     "/user/{id}/edit",      "App\Controller\UserController::update",    ['HEAD', 'GET', 'POST']],
    // ["user:delete",     "/user/{id}/delete",    "App\Controller\UserController::delete",    ['HEAD', 'GET', 'DELETE']],

    
    // 404
    ["error:404",       null,                   "App\Controller\ErrorController::err404",      ['HEAD', 'GET']],
];