<?php 

// Duplicate "config-sample.php" to "config.php"
// Adn add these lines

// Cache System
const CACHE_EXPIRE = 60; // in second
const CACHES_PATH = "./../cache/";

// Templates 
const TEMPLATE_PATH = "./../src/View/pages/";
const TEMPLATE_TYPE = ".php";

// Utils functions
const UTILS_PATH = "./../utils/";

// Database
const DB_HOST    = "127.0.0.1";
const DB_PORT    = "3306";
const DB_USER    = "";
const DB_PASS    = "";
const DB_SCHEMA  = "";
const DB_CHARSET = "";