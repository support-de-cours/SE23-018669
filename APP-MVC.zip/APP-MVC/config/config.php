<?php

// Cache System
const CACHE_EXPIRE = 60; // in second
const CACHES_PATH = "./../cache/";
const ALLOW_CACHE = false;

// Templates 
const TEMPLATE_PATH = "./../src/View/pages/";
const TEMPLATE_TYPE = ".php";

// Utils functions
const UTILS_PATH = "./../utils/";

// Database
const DB_HOST    = "127.0.0.1";
const DB_PORT    = "3306";
const DB_USER    = "osw3"; // root
const DB_PASS    = "myosw3sql"; // chaine vide
const DB_SCHEMA  = "db_demo";
const DB_CHARSET = "utf8";