<?php 
namespace App\Abstract;

abstract class ControllerAbstract
{
    private string $controller;

    /**
     * Bridge of Model Methods
     */
    protected $model;

    function __construct()
    {
        create_crsf_token();
        
        // Defini le controller qui apple la class "ControllerAbstract"
        $this->controller = $this->defineCalledController();

        // Definition et instance de la classe model associé au controller courant
        $modelClassName = $this->getModelClassName();
        if (class_exists($modelClassName))
        {
            $this->model = new $modelClassName;
        }
    }

    private function defineCalledController(): string
    {
        $class = get_called_class();
        $class = explode("\\", $class);
        $class = end($class);
        $class = str_replace("Controller", '', $class);

        return $class;
    }

    private function getModelClassName(): string 
    {
        return "App\\Model\\".$this->controller . "Model";
    }

    protected function currentRoute(): array 
    {
        global $route;
        global $uri;

        $re_route = strToRegex('/', $route[1]);
        preg_match("@^".$re_route."$@i", $uri, $matches);



        return [
            $route, 
            $uri,
            'params' => [
                'id' => $matches[1]
            ]
        ];
    }

    protected function render(string $template, array $data=[]): string
    {
        // ReBuild locale variable
        // form: $data['books] => Array
        // to:   $books = Array
        foreach ($data as $key => $value)
        {
            $$key = $value;
        }

        // A. Sortie direct (dans le navigatuer)
        // include_once TEMPLATE_PATH.$template.TEMPLATE_TYPE;;

        // B. Mise ne tampon de la sortie
        ob_start(); 
        include TEMPLATE_PATH.$template.TEMPLATE_TYPE;
        return ob_get_clean(); 
    }
}