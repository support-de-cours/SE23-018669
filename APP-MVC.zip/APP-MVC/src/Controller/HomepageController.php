<?php 
namespace App\Controller;

use App\Abstract\ControllerAbstract;

class HomepageController extends ControllerAbstract
{
    // Homepage - index
    public function index()
    {
        // Rend la vue du fichier homepage/index.php
        return $this->render("homepage/index");
    }
}