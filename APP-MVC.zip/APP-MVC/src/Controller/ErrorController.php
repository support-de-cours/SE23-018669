<?php 
namespace App\Controller;

class ErrorController
{
    // Error - err404
    public function err404()
    {
        // Change le code reponse HTTP
        header('HTTP/1.0 404 Not Found');

        // ...

        // Rend la vue du fichier error/404.php
        include_once "./../src/View/pages/error/404.php";
    }
}