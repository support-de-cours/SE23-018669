<?php 
namespace App\Controller;

use App\Abstract\ControllerAbstract;

class BookController extends ControllerAbstract
{
    // Book - index
    function index()
    {
        $books = $this->model->all();

        // Rend la vue du fichier book/index.php
        return $this->render("book/index", [
            'books' => $books
        ]);
    }

    // Book - create
    function create()
    {
        // print_r( $_SESSION);

        // $crsf_salt = "abc";
        $crsf_token = $_SESSION['crsf_token'];

        $title = null;
        $description = null;
        $price = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            $errors = [];


            // Recup de données du formulaire
            // ... 

            if (!check_crsf_token( $_POST['_crsf'] ?? null ))
            {
                array_push($errors, "Invalid Token");
            }
            
            // Controle des donnée 
            // ...


            if (empty($errors))
            {
                unset($_POST['_crsf']);
                $id = $this->model->add($_POST);

                if ($id)
                {
                    header("location: ". url('book:read', ['id' => $id]));
                    exit;
                }
            }

            else {
                print_r($errors);
                exit;
            }
        }

        // Rend la vue du fichier book/create.php
        return $this->render("book/create", [
            'crsf_token'  => $crsf_token,
            'title'       => $title,
            'description' => $description,
            'price'       => $price,
        ]);
    }

    // Book - read
    function read()
    {
        $route = $this->currentRoute();
        $book_id = $route['params']['id'];

        $book = $this->model->one($book_id);

        if (!$book)
        {
            header('HTTP/1.0 404 Not Found');
        }
        
        // Rend la vue du fichier book/read.php
        return $this->render("book/read", [
            'book' => $book
        ]);
    }

    // Book - update
    function update()
    {
        // Rend la vue du fichier book/update.php
        include_once "./../src/View/pages/book/update.php";
    }

    // Book - delete
    function delete()
    {
        // Rend la vue du fichier book/delete.php
        include_once "./../src/View/pages/book/delete.php";
    }
}