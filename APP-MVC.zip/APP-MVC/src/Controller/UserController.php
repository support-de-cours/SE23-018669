<?php 
namespace App\Controller;

class UserController
{
    // User - index
    function index()
    {
        // Rend la vue du fichier user/index.php
        include_once "./../src/View/pages/user/index.php";
    }

    // User - create
    function create()
    {
        // Rend la vue du fichier user/create.php
        include_once "./../src/View/pages/user/create.php";
    }

    // User - read
    function read()
    {
        // Rend la vue du fichier user/read.php
        include_once "./../src/View/pages/user/read.php";
    }

    // User - update
    function update()
    {
        // Rend la vue du fichier user/update.php
        include_once "./../src/View/pages/user/update.php";
    }

    // User - delete
    function delete()
    {
        // Rend la vue du fichier user/delete.php
        include_once "./../src/View/pages/user/delete.php";
    }
}