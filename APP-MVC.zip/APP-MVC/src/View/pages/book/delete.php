<!-- Execution de la suppression -->

<!-- Recup des données d'un livre -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Our Books</h1>
    <p>Liste des livres</p>

    <!-- Form de validation de suppression -->
        <!-- OUI : btn submit -->
        <!-- NON : lien > vers read -->

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
