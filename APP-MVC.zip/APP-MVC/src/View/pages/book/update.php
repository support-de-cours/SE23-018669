<!-- Traitement du formulaire -->

<!-- Recup des données d'un livre -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Edit a Book</h1>
    <p>Modifier les données du livre</p>

    <!-- Formulaire -->

    <!-- Btn reset / submit -->

    <!-- Lien : supprimer le livre -->
    <!-- Liens retour à la liste des livres -->

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
