<!-- Traitement du formulaire -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Create a Book</h1>
    <p>Ajouter un livre</p>

    <!-- Formulaire -->
    <form method="post">

        <input type="hidden" name="_crsf" value="<?= $crsf_token ?>">

        <div>
            <label for="title">Titre du livre</label>
            <input type="text" id="title" name="title" value="<?= $title ?>">
        </div>

        <div>
            <label for="description">Description du livre</label>
            <input type="text" id="description" name="description" value="<?= $description ?>">
        </div>

        <div>
            <label for="price">Prix du livre</label>
            <input type="number" step="0.01" min="0" id="price" name="price" value="<?= $price ?>">
        </div>

        <button type="submit">Ajouter</button>
    </form>


    <!-- Liens retour à la liste des livres -->


<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
