<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Our Books</h1>
    <p>Liste des livres</p>

    <hr>
    <a href="<?= url('book:create') ?>">Ajouter un livre</a>
    <hr>

    <!-- Liste des livres -->
    <?php foreach($books as $book): ?>
    <div>
        <h4><?= $book->title ?></h4>
        <p><?= $book->description ?></p>
        <a href="<?= url('book:read', [
            'id' => $book->id
        ], true) ?>">plus d'info</a>
        <!-- lien : detail du livre -->
        <!-- lien : modifier le livre -->
        <hr>
    </div>
    <?php endforeach; ?>

    <!-- Pagination -->


<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
