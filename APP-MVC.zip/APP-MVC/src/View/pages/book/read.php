<!-- Recup des données d'un livre -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Book details</h1>
    <p>Informations sur un livre</p>

    <?php if (!$book): ?>

        <div>The book is not found.</div>
        
    <?php else: ?>

        <!-- title -->
        <div>Title : <?= $book->title ?></div>
        
        <!-- Description -->
        <div>Description : <?= $book->description ?></div>
        
        <!-- price -->
        <div>Price : <?= $book->price ?></div>

        <!-- Lien : modifier le livre -->
        <!-- Lien : supprimer le livre -->
        <!-- Lien : retour à la liste des livres -->
        
    <?php endif; ?>

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
