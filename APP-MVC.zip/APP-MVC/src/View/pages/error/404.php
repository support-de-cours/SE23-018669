<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Ooops, resource not found</h1>

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
