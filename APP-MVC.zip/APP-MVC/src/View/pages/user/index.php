<!-- Recup des utilisateurs -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Our Users</h1>
    <p>Liste des utilisateurs</p>


    <!-- Action (btn ajouter un utilisateur) -->

    <!-- Liste des utilisateurs -->
        <!-- lien : detail du utilisateur -->
        <!-- lien : modifier le utilisateur -->

    <!-- Pagination -->


<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
