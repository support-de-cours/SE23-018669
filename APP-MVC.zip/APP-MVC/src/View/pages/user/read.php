<!-- Recup des données d'un utilisateur -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>User details</h1>
    <p>Informations sur un utilisateur</p>


    <!-- title -->
    <!-- Description -->
    <!-- price -->

    <!-- Lien : modifier le utilisateur -->
    <!-- Lien : supprimer le utilisateur -->
    <!-- Lien : retour à la liste des utilisateurs -->


<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
