<!-- Traitement du formulaire -->

<!-- Recup des données d'un utilisateur -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Edit a User</h1>
    <p>Modifier les données de l'utilisateur</p>

    <!-- Formulaire -->

    <!-- Btn reset / submit -->

    <!-- Lien : supprimer le utilisateur -->
    <!-- Liens retour à la liste des utilisateurs -->

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
