<!-- Execution de la suppression -->

<!-- Recup des données d'un utilisateur -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Our Users</h1>
    <p>Liste des utilisateurs</p>

    <!-- Form de validation de suppression -->
        <!-- OUI : btn submit -->
        <!-- NON : lien > vers read -->

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
