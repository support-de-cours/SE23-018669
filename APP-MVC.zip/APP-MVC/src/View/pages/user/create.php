<!-- Traitement du formulaire -->

<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Create a User</h1>
    <p>Ajouter un utilisateur</p>


    <!-- Formulaire -->

    <!-- Btn reset / submit -->

    <!-- Liens retour à la liste des utilisateurs -->


<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
