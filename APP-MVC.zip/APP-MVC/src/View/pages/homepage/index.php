<?php include "./../src/View/layout/header.php" ?>

<!-- ----------------------------------- -->

    <h1>Ma Super App (homepage)</h1>

<!-- ----------------------------------- -->

<?php include "./../src/View/layout/footer.php" ?>
