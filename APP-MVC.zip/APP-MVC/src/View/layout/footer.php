    </div>

    <footer class="site-footer">
        <div class="footer-nav">
            <a href="<?= url('homepage') ?>">Homepage</a>
        </div>
        <div class="copyright">
            &copy; 2023 Ma Super App !
        </div>
    </footer>

</body>
</html>