<?php 
namespace App\Model;

use App\Abstract\ModelAbstract;

class UserModel extends ModelAbstract {}
