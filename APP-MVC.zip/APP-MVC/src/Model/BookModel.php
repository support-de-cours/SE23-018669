<?php 
namespace App\Model;

use App\Abstract\ModelAbstract;

class BookModel extends ModelAbstract
{
    // public function myCustomQuery() 
    // {
    //     // Requete cutom
    //     $sql = "SELECT * FROM `user`";
    //     $query = $this->connection->query( $sql );
    //     return $query->fetchAll(\PDO::FETCH_OBJ);
    // }
}
