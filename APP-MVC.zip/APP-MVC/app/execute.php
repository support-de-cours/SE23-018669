<?php 

// EXECUTE L'AFFICHAGE DE LA PAGE
// --

// Controller full name
$controller = $route[2];
$controller = explode("::", $controller);

// Controller Class
$controller_class = $controller[0] ?? null;

// Controller Method
$controller_method = $controller[1] ?? "index";

// Check controller class
if ($controller_class === null)
{
    throw new \Exception("Controller Class is not defined", 42);
}

// Instantiate controller & method
cache($controller_class, $controller_method);