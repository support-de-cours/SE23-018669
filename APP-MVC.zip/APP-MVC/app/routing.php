<?php 

// Recup la definition des route
$routes = require_once "../config/routes.php";

// On s'assure que $routes est un tableau
if (!is_array($routes))
{
    $routes = [];
}



// Definition de la variable $uri
$uri = "/";

// Récupération de l'uri courant
if (!empty($_SERVER['REQUEST_URI'])) 
{
    $uri = $_SERVER['REQUEST_URI']; 
}



// Recherche de l'URI dans le tableau de routage
foreach ($routes as $route) 
{
    if ($route[1] !== null)
    {
        $re = strToRegex("/", $route[1]);

        // if ($route[1] == $uri) 
        if (preg_match("@^".$re."$@", $uri)) 
        {
            // $GLOBALS['route_active'] = $route[0];
            break;
        }
    }
}