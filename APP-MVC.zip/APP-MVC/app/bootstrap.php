<?php 
// Timing Script Execution (Start)
$tse_start = microtime(true);

session_start();

// Ajout de l'autoload (PSR-4)
require_once "../vendor/autoload.php";

try {
    // Injection de la config de l'application
    $config_file = "../config/config.php";

    if (!file_exists($config_file))
    {
        throw new Exception("Config file does not exist. You must create the file \"config/config.php\"", 123);
    }
    require_once $config_file;

    // Connexion BDD
    require_once "dbconnect.php";

    // "Autoload" des fichiers PHP du repertoire "utils"
    require_once "utils.php";

    // Analyse de la route (url)
    require_once "routing.php";

    // Execution du controller de la page
    require_once "execute.php";
}
catch (Exception $e) {
    
    echo 'Message d\'erreur : ' .$e->getMessage();
    echo '<br>';
    echo 'Code d\'erreur : ' .$e->getCode();
}

// Timing Script Execution (End)
$tse_end = microtime(true);
$tse = $tse_end - $tse_start;

// echo $tse;