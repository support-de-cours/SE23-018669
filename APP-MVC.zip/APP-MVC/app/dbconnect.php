<?php 

$dsn = "mysql:";
$dsn.= "host=".DB_HOST.";";
$dsn.= "port=".DB_PORT.";";
$dsn.= "dbname=".DB_SCHEMA.";";
$dsn.= "charset=".DB_CHARSET.";";

// Connexion BDD
try {
    $db = new \PDO($dsn, DB_USER, DB_PASS);
}
// Arret du script en cas d'erreur de connexion à la BDD
catch(PDOException $e) 
{
    throw new Exception("Échec de la connexion",  $e->getCode());
}